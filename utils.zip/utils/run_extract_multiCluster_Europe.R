#######################################################
##### USEFUL FUNCTIONS
#######################################################
source("./utils/sim_utils.R")

#######################################################
##### EXTRACT DATA
#######################################################
## Define here the directory to find the data from
## https://zenodo.org/records/6513429
infolder  <- "../../clusteredData/data"

## directory where to store results
outfolder <- paste0("./data_EUR/",CASE0,"/")

## read data
msk <- rast(file.path(infolder, "TOTmask.tif"))
newcrs <- crs(msk)
strata <- vect(file.path(infolder,"strata.shp"))
OCSstack <- rast(file.path(infolder, paste0(CASE0,"stack.tif")))

#######################################################
##### CLUSTER
#######################################################
idx <- as.integer(CASE)
ndx <- setdiff(1:100, idx)
msk1 <- mask(msk, strata[idx,])
msk2 <- mask(msk, strata[ndx,])

set.seed(SEED)
subC <- sample(cells(msk1), N)
OCSdataC <- terra::extract(OCSstack, subC)
OCSdataC <- na.omit(OCSdataC)
nnc  <- nrow(OCSdataC)
set.seed(SEED)
subOC <- sample(cells(msk2), NN - N)
OCSdataOC <- terra::extract(OCSstack, subOC)
OCSdataOC <- na.omit(OCSdataOC)
OCSdata.train <- rbind(OCSdataC, OCSdataOC)
OCSdata.train$glc2017 <- factor(OCSdata.train$glc2017, levels=1:8)

if (CASE0 == "OCS") qui_cov = names(OCSdata.train)[c(18,19,2:17,20,1)]
if (CASE0 == "AGB") qui_cov = names(OCSdata.train)[c(21,22,2:20,23,1)]

OCSdata.train = OCSdata.train[,qui_cov]

#######################################################
##### FORMAT, SAVE, TRAIN, TEST
#######################################################
print(dim(OCSdata.train))
fname <- paste0("OCSdata_clust_train_Nc", Nc,".Rdata")
names(OCSdata.train)[1:2] = c("x","y")
save(OCSdata.train, file=file.path(outfolder, fname))

