#######################################################
##### USEFUL FUNCTIONS
#######################################################
source("./utils/sim_utils.R")

#######################################################
##### EXTRACT DATA
#######################################################
## read data
msk <- rast(file.path(infolder, "TOTmask.tif"))
newcrs <- crs(msk)
strata <- vect(file.path(infolder,"strata.shp"))
OCSstack <- rast(file.path(infolder, paste0(CASE0,"stack.tif")))

#######################################################
##### EXTRACT CLUSTER
#######################################################
idx <- CASE
ndx <- setdiff(1:100, idx)
msk1 <- mask(msk, strata[idx,])
msk2 <- mask(msk, strata[ndx,])
## Extract observations randomly (except for the same geostratum than the SIC case)
set.seed(SEED)
subOC <- sample(cells(msk2), NN )
OCSdataOC <- terra::extract(OCSstack, subOC)
OCSdataOC <- na.omit(OCSdataOC)
OCSdata.train <- OCSdataOC#rbind(OCSdataC, OCSdataOC)
OCSdata.train$glc2017 <- factor(OCSdata.train$glc2017, levels=1:8)

## reorder variables
qui_cov = names(OCSdata.train)[c(18,19,2:17,20,1)]
OCSdata.train = OCSdata.train[,qui_cov]

#######################################################
##### GRID
#######################################################
set.seed(1234567)
esamp <- 12400  
extSmp <- spatSample(msk, esamp, method="regular", as.points=T)
maxShft <- 11500 # min(distance(extSmp)) * 0.5
shftSmp <- shift(extSmp, runif(1, -maxShft, maxShft), 
                   runif(1, -maxShft, maxShft))
tst <- terra::extract(msk, shftSmp)
idx <- which(tst[,2] == 1)
shftSmp <- shftSmp[idx,]
 
OCSdata.regular <- terra::extract(OCSstack, shftSmp)
OCSdata.regular$ID <- NULL
OCSdata.regular = OCSdata.regular[,qui_cov]
OCSdata.regular$glc2017 <- factor(OCSdata.regular$glc2017, levels=1:8)

fname <- paste0("OCSdata_regular", ".Rdata")
names(OCSdata.regular)[1:2] = c("x","y")
save(OCSdata.regular , file=file.path(outfolder, fname))

#######################################################
##### FORMAT, SAVE, TRAIN, TEST
#######################################################
print(dim(OCSdata.train))
fname <- paste0("OCSdata_rand_train", ".Rdata")
names(OCSdata.train)[1:2] = c("x","y")
save(OCSdata.train, file=file.path(outfolder, fname))
